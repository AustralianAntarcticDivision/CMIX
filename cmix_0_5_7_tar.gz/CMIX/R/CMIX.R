###################################################################################################
# Front-end R package for CMIX executable
# Australian Antarctic Division
# Troy Robertson
# 24 June 2013
# Version 0.5.4
# Revision 0.5.6 12/9/2016 TR - Fixed .maxColWidth to exclude NA lines beforehand because of changes to nchar function
###################################################################################################

# CMIX S4 class
setClass("CMIX",
	representation(.errorMsgs 		= "list",
				   .runout			= "character",
				   .infileLines		= "character",
				   
				   # file paths
				   hauldatafilepath = "character",
				   infilepath		= "character",		
				   outfilepath		= "character",
				   
				   header			= "character",
				   haulData			= "data.frame",	
				   # Bounds
				   components		= "matrix",	
				   # Standard Deviation
				   linearlyRelated	= "logical",
				   
				   # - Linear
				   loLinIntr		= "numeric",
				   upLinIntr		= "numeric",
				   loLinSlope		= "numeric",
				   upLinSlope		= "numeric",
				   stValIntr		= "numeric",
				   stepLenIntr		= "numeric",
				   stValSlope		= "numeric",
				   stepLenSlope		= "numeric",
				   # - Independent
				   sdBounds			= "matrix",	
				   
				   # von Bertalanffy
				   birthday			= "numeric",
				   surveyStartDay	= "numeric",
				   t0				= "numeric",
				   K				= "numeric",
				   Linfinity		= "numeric",
				   proportion		= "numeric",
				   firstCohort		= "numeric",
				   numCohorts		= "numeric",
				   useCandyDecay	= "logical",
				   decay			= "numeric",
				   cutoff			= "numeric",
				   
				   # Settings
				   minimisation		= "logical",
				   fitQuadSurface	= "logical",
				   plotFittedFn 	= "logical",
				   plotResidualFn	= "logical",
				   plotToScreen		= "logical",
				   plotToPlotter	= "logical",
				   plotToPrinter 	= "logical",
				   plotToFile		= "logical",
				   maxFnCalls		= "numeric",
				   minimRepFreq		= "numeric",
				   stoppingCrit		= "numeric",
				   freqConvTest		= "numeric",
				   simpleExpCoeff	= "numeric",
				   skipLeadInts		= "numeric"
				   ),			#
				   
	prototype(	   .errorMsgs 		= list(),
				   .runout			= "",
				   .infileLines		= "",
				   
				   # file paths
				   hauldatafilepath = "",	
				   infilepath		= "",				
				   outfilepath		= "",
				   
				   header			= "Mixtures input file",
				   haulData			= data.frame(),		
				   # Bounds
				   components		= matrix(nrow=0,ncol=0),
				   # Standard Deviation
				   linearlyRelated	= TRUE,
				   # - Linear
				   loLinIntr		= 1,
				   upLinIntr		= 50,
				   loLinSlope		= 0.0,
				   upLinSlope		= 0.4,
				   stValIntr		= 15,
				   stepLenIntr		= 1,
				   stValSlope		= 0.07,
				   stepLenSlope		= 0.01,
				   # - Independent
				   sdBounds			= matrix(nrow=0,ncol=0),
				  
				   # von Bertalanffy
				   birthday			= 1,
				   surveyStartDay	= 0,
				   t0				= 0,
				   K				= 1,
				   Linfinity		= 1,
				   proportion		= 0.5,
				   firstCohort		= 1,
				   numCohorts		= 0,
				   useCandyDecay	= FALSE,
				   decay			= 0,
				   cutoff			= 0,
				   
				   # Settings
				   minimisation		= TRUE,
				   fitQuadSurface	= FALSE,
				   plotFittedFn 	= TRUE,
				   plotResidualFn	= TRUE,
				   plotToScreen		= FALSE,
				   plotToPlotter	= FALSE,
				   plotToPrinter 	= FALSE,
				   plotToFile		= TRUE,
				   maxFnCalls		= 10000,
				   minimRepFreq		= 100,
				   stoppingCrit		= 0.000001,
				   freqConvTest		= 5,
				   simpleExpCoeff	= 1,
				   skipLeadInts		= 0
				   )
)

setMethod("initialize", "CMIX",
	function(.Object, hauldatafilepath, ...) {
		if (!missing(hauldatafilepath)) {
			if (!file.exists(hauldatafilepath)) stop("Haul data file cannot be found at: ", hauldatafilepath)
			.Object@haulData <- read.csv(hauldatafilepath, row.names=1)
		}
		
		.Object <- callNextMethod(.Object, ...)	
		
		if (ncol(.Object@components) == 2) colnames(.Object@components) <- c("Lower", "Upper")
		if (ncol(.Object@components) == 3) colnames(.Object@components) <- c("Lower", "Upper", "Mean")
		if (ncol(.Object@sdBounds) == 2) colnames(.Object@sdBounds) <- c("Lower", "Upper")
		if (ncol(.Object@sdBounds) == 3) colnames(.Object@sdBounds) <- c("Lower", "Upper", "Fixed SD")
		
		return(.Object)
	}
)

setGeneric("setVBBounds", function(.Object, birthday="integer", surveyStartDay="integer", t0="numeric", K="numeric", 
						Linfinity="numeric", proportion="numeric", firstCohort="integer", numCohorts="integer", 
						withmeans="logical", useCandyDecay="logical", decay="numeric", cutoff="numeric") standardGeneric("setVBBounds"))
setMethod("setVBBounds", "CMIX",
    function(.Object, birthday=1, surveyStartDay=0, t0=0, K=1, Linfinity=1, proportion=0.5, firstCohort=1, numCohorts=1,
				   withmeans=FALSE, useCandyDecay=FALSE, decay=0, cutoff=0) {
				   
		if (!missing(birthday)) .Object@birthday=birthday
		if (!missing(surveyStartDay)) .Object@surveyStartDay=surveyStartDay
		if (!missing(t0)) .Object@t0=t0
		if (!missing(K)) .Object@K=K
		if (!missing(Linfinity)) .Object@Linfinity=Linfinity
		if (!missing(proportion)) .Object@proportion=proportion
		if (!missing(firstCohort)) .Object@firstCohort=firstCohort
		if (!missing(numCohorts)) .Object@numCohorts=numCohorts
		if (!missing(useCandyDecay)) .Object@useCandyDecay=useCandyDecay
		if (!missing(decay)) .Object@decay=decay
		if (!missing(cutoff)) .Object@cutoff=cutoff
		
		.Object@components <- .findVBBounds(.Object, withmeans)
		
		return(invisible(.Object))
	}
)

setGeneric("parseInput", function(.Object, infilepath="character") standardGeneric("parseInput"))
setMethod("parseInput", "CMIX",
	function(.Object, infilepath) {
		if (missing(infilepath) && (is.null(.Object@infilepath) || .Object@infilepath == "")) {
			stop("CMIX object must have a path to a CMIX input file either assigned to slot or passed to this method!")
		}
		if (!missing(infilepath) && file.exists(infilepath)) .Object@infilepath <- infilepath
		if (!file.exists(.Object@infilepath)) stop("CMIX input file '", .Object@infilepath, "' cannot be found!")
		.Object <- .parse(.Object)
		
		return(invisible(.Object))
	}
)

setGeneric("buildInput", function(.Object, infilepath="character") standardGeneric("buildInput"))
setMethod("buildInput", "CMIX",
	function(.Object, infilepath) {
		if (missing(infilepath) && (is.null(.Object@infilepath) || .Object@infilepath == "")) {
			stop("CMIX object must have a path to a CMIX input file either assigned to slot or passed to this method!")
		}
		if (!missing(infilepath)) .Object@infilepath <- infilepath
		.Object <- .build(.Object)
		
		return(invisible(.Object))
	}
)

setGeneric("runInput", function(.Object, infilepath="character", outfilepath="character", buildfirst="logical") standardGeneric("runInput"))
setMethod("runInput", "CMIX",
	function(.Object, infilepath, outfilepath, buildfirst=FALSE) {
		#if (R.Version()$arch != "i386") {
		#	stop("CMIX.exe executable is only compiled for a Windows 386 architecture!")
		#}
		if (missing(infilepath) && (is.null(.Object@infilepath) || .Object@infilepath == "")) {
			stop("CMIX object must have a path to a CMIX input file either assigned to slot or passed to this method!")
		}
		if (!missing(infilepath)) .Object@infilepath <- infilepath
		
		# Does an input file need to be built from this object first?
		if (buildfirst) .Object <- buildInput(.Object, infilepath)
		.Object@.errorMsgs <- list()
			
		if (missing(outfilepath)) {
			if (is.null(.Object@outfilepath) || .Object@outfilepath == "")
				#.Object@outfilepath <- file.path(getwd(), basename(.Object@infilepath))
				# strip off file extension and add .out
				.Object@outfilepath <- paste(sub("[.][^.]*$", "", basename(.Object@infilepath)), ".out", sep="")
		} else {
			.Object@outfilepath <- outfilepath
		}
		if (file.exists(.Object@outfilepath)) file.remove(.Object@outfilepath)
		
		.Object <- .run(.Object)
		
		# Check that an error wasn't output
		if (length(.Object@.runout) > 0 && substr(.Object@.runout[[1]], 1, 7) == "forrtl:") {
			cat("Likely format error in CMIX input file at: ", .Object@infilepath, "\n", sep="")
			stop(.Object@.runout)
		}
		# Check that output file was produced
		if (!file.exists(.Object@outfilepath)) {
			cat("CMIX failed to produce an output file at: ", .Object@outfilepath, "\n", sep="")
			stop(.Object@.runout)
		}
		# Check that it was able to converge "*** ERROR: !!! Unable to converge on minimum !!! ***
		if (length(grep("Unable to converge on minimum", readLines(.Object@outfilepath)))) {
			stop("CMIX failed to converge on a minimum!")
		}
		.Object@.runout <- ""
		
		return(invisible(.Object))
	}
)

setGeneric("isValid", function(.Object) standardGeneric("isValid"))
setMethod("isValid", "CMIX",
    function(.Object) {
		.Object <- .validate(.Object)
		for (em in seq_along(.Object@.errorMsgs)) message(.Object@.errorMsgs[[em]], "\n")
		
		return(length(.Object@.errorMsgs) == 0)
	}
)
	

setGeneric("getParam", function(.Object, slotName="character") standardGeneric("getParam"))
setMethod("getParam", "CMIX",
    function(.Object, slotName) {
		if (missing(slotName)) stop("A named slot is required!")
		if (!(slotName %in% slotNames(.Object))) stop("'", slotName, "' is not a valid slot of this CMIX object!")
		
		return(slot(.Object, slotName))
	}
)

setGeneric("setParam", function(.Object, slotName="character", value) standardGeneric("setParam"))
setMethod("setParam", "CMIX",
    function(.Object, slotName, value) {
		if (missing(slotName)) stop("A named slot is required for assignment!")
		if (missing(value)) stop("A value is required for assignment to slot '", slotName, "'!")
		if (!(slotName %in% slotNames(.Object))) stop("'", slotName, "' is not a valid slot of this CMIX object!")
		slot(.Object, slotName) <- value
		
		return(.Object)
	}
)

setGeneric(".findVBBounds", function(.Object, withmeans="logical") standardGeneric(".findVBBounds"))
setMethod(".findVBBounds", "CMIX",
    function(.Object, withmeans=FALSE) {
		if (.Object@numCohorts <= 0) stop("Von Bertallanfy: Number of cohorts must be > 0!")
		if (.Object@firstCohort <= 0) stop("Von Bertallanfy: First cohort must be aged > 0!")
		
		cohortBounds <- matrix(nrow=0,ncol=4)
		endCohort <- .Object@firstCohort + .Object@numCohorts - 1
		whichCohort <- 0
		for (cohort in .Object@firstCohort:endCohort) {
			age <- .calculatedAge(.Object, cohort)
			meanLength <- round(.cohortLen(.Object, cohort))
			lowerBound <- round(meanLength - (.Object@proportion * (.cohortLen(.Object, cohort+1) - meanLength)))
			upperBound <- round(meanLength + (.Object@proportion * (.cohortLen(.Object, cohort+1) - meanLength)))
			
			cohortBounds <- rbind(cohortBounds, c(age, lowerBound, upperBound, meanLength))
		}
		
		rownames(cohortBounds) <- round(subset(cohortBounds, select=1),2)
		if (withmeans) {
			cohortBounds <- subset(cohortBounds, select=c(2,3,4))
			colnames(cohortBounds) <- c("Lower", "Upper", "Mean")
		} else {
			cohortBounds <- subset(cohortBounds, select=c(2,3))
			colnames(cohortBounds) <- c("Lower", "Upper")
		}
		
		return(cohortBounds)
	}
)
	
setGeneric(".cohortLen", function(.Object, cohort="integer") standardGeneric(".cohortLen"))
setMethod(".cohortLen", "CMIX",
    function(.Object, cohort) {
		if (.Object@surveyStartDay >= .Object@birthday) {
			tN <- ((.Object@surveyStartDay - .Object@birthday) / 365) + cohort
		} else {
			tN <- ((365 - .Object@birthday + .Object@surveyStartDay) / 365) + cohort
		}
		cLength <- .Object@Linfinity * (1 - exp(-1 * .Object@K * (tN - .Object@t0)))
		# if decay passed and age is less than cutoff
		if (.Object@useCandyDecay && .Object@decay > 0 && tN < .Object@cutoff) {
			cLength <- cLength * exp((tN - .Object@cutoff) * .Object@decay)
		}
		
		return(cLength)
	}
)

setGeneric(".calculatedAge", function(.Object, cohort="integer") standardGeneric(".calculatedAge"))
setMethod(".calculatedAge", "CMIX",
    function(.Object, cohort) {
		if (.Object@surveyStartDay >= .Object@birthday) {
			return(cohort + ((.Object@surveyStartDay - .Object@birthday) / 365))
		} else {
			return(cohort + ((365 - .Object@birthday + .Object@surveyStartDay) / 365))
		}
	}
)

setGeneric(".validate", function(.Object) standardGeneric(".validate"))
setMethod(".validate", "CMIX",
    function(.Object) {
		.Object@.errorMsgs <- list()
		
		if (ncol(.Object@haulData) <= 0) stop("haulData must contain at least one haul record!")
		if (is.null(dimnames(.Object@haulData)[[2]])) stop("haulData must contain column dimnames representing lower bin components!")
		
		# validation tests
		# Must have components
		if (ncol(.Object@components) <= 0) 
			.Object@.errorMsgs <- c(.Object@.errorMsgs, "At least one component (cohort) must be bounded!")
		# If component means then mean has to be between bounds
		if (ncol(.Object@components) == 3) {
			if (FALSE %in% (.Object@components[,3] > .Object@components[,1]) || FALSE %in% (.Object@components[,3] < .Object@components[,2])) 
				.Object@.errorMsgs <- c(.Object@.errorMsgs, "Each component mean must fall between its bounds!")
		}
		# number of sdBounds must match number of components
		if (!.Object@linearlyRelated && ncol(.Object@sdBounds) != ncol(.Object@components)) 
			.Object@.errorMsgs <- c(.Object@.errorMsgs, "If mixture SDs are not linearly related, then bounds must be specified for each component!")
		
        return(.Object)
	}
)

setGeneric(".build", function(.Object) standardGeneric(".build"))
setMethod(".build", "CMIX",
    function(.Object) {
		# TODO Catch errors and close connection (or write to string? and then to file when done?
		if (!isValid(.Object)) stop("Ending CMIX build")

		# Spit it out
		conn <- file(.Object@infilepath, open="w")
		on.exit(close(conn))
		
		cat(.Object@header, "\n\n", file=conn, append=TRUE)
		
		cat(.padTo("NUMBER OF COMPONENTS IN MIXTURE", nrow(.Object@components)), "\n\n", sep="", file=conn, append=TRUE)
		
		cat("Bounds on the means of the components\n", sep="", file=conn, append=TRUE)
		cat("Component  Low Bound  High Bound\n", sep="", file=conn, append=TRUE)
		if (nrow(.Object@components) > 0) {
			for (co in 1:nrow(.Object@components)) {
				cat(.padTo("", co, 5), 
					.padTo("", .Object@components[co,1], 10 - nchar(co)), 
					.padTo("", .Object@components[co,2], 12 - nchar(.Object@components[co,1])), "\n", sep="", file=conn, append=TRUE)
			}
		}
		cat("\n", file=conn, append=TRUE)
		
		cat("Components with means to be held constant (-1) is end of list\n", sep="", file=conn, append=TRUE)
		cat("Component  Fixed mean\n", sep="", file=conn, append=TRUE)
		if (ncol(.Object@components) == 3) {
			for (co in 1:nrow(.Object@components)) {
				cat(.padTo("", co, 5), 
					.padTo("", .Object@components[co, 3], 11 - nchar(co)), "\n", sep="", file=conn, append=TRUE)
			}
		}
		# Ends list.
		cat(.padTo("", -1, 10), .padTo("", 0, 9), "\n", sep="", file=conn, append=TRUE)
		# CMIX does not like a space after this wierd end of input symbol
		# Oh... Unless of course there were no means. Then it does.
		if (ncol(.Object@components) != 3 || nrow(.Object@components) == 0) cat("\n", file=conn, append=TRUE)
		
		cat(.padTo("MIX Std. Devs LINEARLY RELATED", .logAsChar(.Object@linearlyRelated)), "\n\n", sep="", file=conn, append=TRUE)
		# But it definitely wants one here or else...
		cat("The following 8 parameters are only used if LINEARLY RELATED is TRUE\n", file=conn, append=TRUE)
		cat(.padTo("LOWER BOUND ON LINEAR INTERCEPT", .Object@loLinIntr), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("UPPER BOUND ON LINEAR INTERCEPT", .Object@upLinIntr), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("LOWER BOUND ON LINEAR SLOPE", .Object@loLinSlope), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("UPPER BOUND ON LINEAR SLOPE", .Object@upLinSlope), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("STARTING VALUE FOR INTERCEPT SEARCH", .Object@stValIntr), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("STEP LENGTH FOR INTERCEPT", .Object@stepLenIntr), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("STARTING VALUE FOR SLOPE SEARCH", .Object@stValSlope), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("STEP LENGTH FOR SLOPE", .Object@stepLenSlope), "\n\n", sep="", file=conn, append=TRUE)
		
		cat("Bounds on the standard deviations of the components (Only if LINEAR is false)\n", sep="", file=conn, append=TRUE)
		cat("Component  Low bound  High bound\n", sep="", file=conn, append=TRUE)
		for (co in 1:nrow(.Object@components)) {
			if (co <= nrow(.Object@sdBounds)) {
				cat(.padTo("", co, 5), 
					.padTo("", .Object@sdBounds[co,1], 11 - nchar(co)), 
					.padTo("", .Object@sdBounds[co,2], 11 - nchar(.Object@sdBounds[co,1])), "\n", sep="", file=conn, append=TRUE)
			} else {
				# WELL... CMIX still wants any rubbish if linear is FALSE
				cat(.padTo("", co, 5), 
					.padTo("", co, 11 - nchar(co)), 
					.padTo("", co, 11 - nchar(co)), "\n", sep="", file=conn, append=TRUE)
			}
		}
		cat("\n", file=conn, append=TRUE)
		
		cat("Components with standard deviations to be held constant (-1) is end of list\n", sep="", file=conn, append=TRUE)
		cat("Component  Fixed std dev.  (Only if LINEAR is false)\n", sep="", file=conn, append=TRUE)
		if (ncol(.Object@sdBounds) == 3) {
			for (co in 1:nrow(.Object@sdBounds)) {
				cat(.padTo("", co, 5), 
					.padTo("", .Object@sdBounds[co,3], 11 - nchar(co)), "\n", sep="", file=conn, append=TRUE)
			}
		}
		# Ends list.
		cat(.padTo("", -1, 4), "\n\n", sep="", file=conn, append=TRUE)
		
		cat(.padTo("MINIMISATION", .logAsChar(.Object@minimisation, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("PLOT FITTED FUNCTION AND DATA", .logAsChar(.Object@plotFittedFn, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("PLOT RESIDUAL FUNCTION OVER P1", .logAsChar(.Object@plotResidualFn, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("PLOT ON SCREEN", .logAsChar(.Object@plotToScreen, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("PLOT ON PLOTTER", .logAsChar(.Object@plotToPlotter, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("PLOT ON PRINTER", .logAsChar(.Object@plotToPrinter, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("PLOT TO FILE", .logAsChar(.Object@plotToFile, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("MAXIMUM NUMBER OF FUNCTION CALLS", .Object@maxFnCalls), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("MINIM REPORTING FREQUENCY", .Object@minimRepFreq), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("STOPPING CRITERIA", .Object@stoppingCrit), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("FREQUENCY FOR CONVERGENCE TESTING", .Object@freqConvTest), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("FIT QUADRATIC SURFACE", .logAsChar(.Object@fitQuadSurface, "YN")), "\n", sep="", file=conn, append=TRUE)
		cat(.padTo("SIMPLEX EXPANSION COEFFICIENT", .Object@simpleExpCoeff), "\n\n", sep="", file=conn, append=TRUE)
		
		cat(.padTo("NUMBER OF LEADING INTERVALS TO SKIP", .Object@skipLeadInts), "\n", sep="", file=conn, append=TRUE)
		
		cat("Bin interval boundaries (mm)", "\n", sep="", file=conn, append=TRUE)
		cat(.padBy(rownames(.Object@haulData), minpad=2), "\n\n", sep="", file=conn, append=TRUE)
		if (length(.Object@haulData) > 0) {
			for (haul in 1:length(.Object@haulData)) {
				if (!is.na(colnames(.Object@haulData)[haul])) {
					cat(.padTo(colnames(.Object@haulData)[haul], haul, 50), "\n", sep="", file=conn, append=TRUE)
					cat(.padBy(.Object@haulData[[haul]], width=.maxColWidth(.Object@haulData)), "\n\n", sep="", file=conn, append=TRUE)
					#cat(.Object@haulData[[haul]], "\n\n", sep="", file=conn, append=TRUE)
				}
			}
		}
		
		cat(.padTo("End of haul data", -1, 50), "\n\n\n", sep="", file=conn, append=TRUE)

		
		cat("Data are numbers of fish per square kilometre", sep="", file=conn, append=TRUE)
		
		return(.Object)
	}
)

setGeneric(".run", function(.Object) standardGeneric(".run"))
setMethod(".run", "CMIX",
    function(.Object) {
		# Find CMIX executable
		cmixLocal <- file.path(".CMIX", basename(system.file("CMIX.exe", package="CMIX")))
		inLocal <- file.path(".CMIX", basename(.Object@infilepath))
		outLocal <- file.path(".CMIX", basename(.Object@outfilepath))
		
		# Move files locally if necessary
		if (!file.exists(".CMIX")) dir.create(".CMIX")
		if (!file.exists(cmixLocal)) file.copy(system.file("CMIX.exe", package="CMIX"), cmixLocal)
		junk <- file.copy(.Object@infilepath, inLocal, overwrite=T)
		
		# Run with appropriate system call dependent on R version
		if ((R.Version()$major == "2") && (R.Version()$minor < "12.0")) {
			.Object@.runout <- system(paste(shQuote(cmixLocal), shQuote(inLocal), shQuote(outLocal)), intern=TRUE)
		} else if (R.Version()$major >= "2") {
			.Object@.runout <- system2(cmixLocal, args=paste(shQuote(inLocal), shQuote(outLocal)), stdout=TRUE, stderr=TRUE)
		}
		# (Re)move files back to expected paths
		junk <- file.remove(inLocal)
		junk <- file.rename(outLocal, .Object@outfilepath)
		unlink(".CMIX", recursive=TRUE)
		
		return(.Object)
	}
)

setGeneric(".parse", function(.Object) standardGeneric(".parse"))
setMethod(".parse", "CMIX",
    function(.Object) {
		# Read file into a list
		.Object@.infileLines <- readLines(.Object@infilepath, warn=F)
		
		.Object@header <- .trim(.Object@.infileLines[[1]])
		ncomp <- as.integer(.scanParam(.Object, "NUMBER OF COMPONENTS IN MIXTURE", posn="right"))
		if (is.na(ncomp)) stop("'", .Object@infilepath, "' does not appear to be a valid CMIX input data file!", sep="")
		
		# Components
		components <- .scanData(.Object, startln=7, stopon="")
		components <- matrix(as.numeric(components), ncol=3, byrow=TRUE)
		components <- subset(components, select=c(2,3))
		compmean <- .scanParam(.Object, "Components with means to be held constant (-1) is end of list", skip=1, stopon="-1")
		if (!is.na(compmean) && length(compmean > 0)) {
			compmean <- matrix(as.numeric(compmean), ncol=1)
			components <- cbind(components, compmean)
		}
		.Object@components <- components
		
		# Linear parameters
		.Object@linearlyRelated <- as.logical(.scanParam(.Object, "MIX Std. Devs LINEARLY RELATED", posn="right"))
		.Object@loLinIntr <- as.numeric(.scanParam(.Object, "LOWER BOUND ON LINEAR INTERCEPT", posn="right"))
		.Object@upLinIntr <- as.numeric(.scanParam(.Object, "UPPER BOUND ON LINEAR INTERCEPT", posn="right"))
		.Object@loLinSlope <- as.numeric(.scanParam(.Object, "LOWER BOUND ON LINEAR SLOPE", posn="right"))
		.Object@upLinSlope <- as.numeric(.scanParam(.Object, "UPPER BOUND ON LINEAR SLOPE", posn="right"))
		.Object@stValIntr <- as.numeric(.scanParam(.Object, "STARTING VALUE FOR INTERCEPT SEARCH", posn="right"))
		.Object@stepLenIntr <- as.numeric(.scanParam(.Object, "STEP LENGTH FOR INTERCEPT", posn="right"))
		.Object@stValSlope <- as.numeric(.scanParam(.Object, "STARTING VALUE FOR SLOPE SEARCH", posn="right"))
		.Object@stepLenSlope <- as.numeric(.scanParam(.Object, "STEP LENGTH FOR SLOPE", posn="right"))
		
		# Bounds on Standard Deviations
		sdBounds <- .scanParam(.Object, "Bounds on the standard deviations of the components", posn="below", skip=1, stopon="")
		sdBounds <- matrix(as.numeric(sdBounds), ncol=3, byrow=TRUE)
		sdBounds <- subset(sdBounds, select=c(2,3))
		sdConst <- .scanParam(.Object, "Components with standard deviations to be held constant", posn="below", skip=1, stopon="-1")
		if (!is.na(sdConst) && length(sdConst > 0)) {
			sdConst <- matrix(as.numeric(sdConst), ncol=1)
			sdBounds <- cbind(sdBounds, sdConst)
		}
		.Object@sdBounds <- sdBounds
		
		# General parameters
		.Object@minimisation <- .logFromChar(.scanParam(.Object, "MINIMISATION", posn="right"))
		.Object@plotFittedFn <- .logFromChar(.scanParam(.Object, "PLOT FITTED FUNCTION AND DATA", posn="right"))
		.Object@plotResidualFn <- .logFromChar(.scanParam(.Object, "PLOT RESIDUAL FUNCTION OVER P1", posn="right"))
		.Object@plotToScreen <- .logFromChar(.scanParam(.Object, "PLOT ON SCREEN", posn="right"))
		.Object@plotToPlotter <- .logFromChar(.scanParam(.Object, "PLOT ON PLOTTER", posn="right"))
		.Object@plotToPrinter <- .logFromChar(.scanParam(.Object, "PLOT ON PRINTER", posn="right"))
		.Object@plotToFile <- .logFromChar(.scanParam(.Object, "PLOT TO FILE", posn="right"))
		.Object@maxFnCalls <- as.numeric(.scanParam(.Object, "MAXIMUM NUMBER OF FUNCTION CALLS", posn="right"))
		if (is.na(.Object@maxFnCalls)) .Object@maxFnCalls <- as.numeric(.scanParam(.Object, "MAXIMUM NUMBER  OF FUNCTION CALLS", posn="right"))
		.Object@minimRepFreq <- as.numeric(.scanParam(.Object, "MINIM REPORTING FREQUENCY", posn="right"))
		.Object@stoppingCrit <- as.numeric(.scanParam(.Object, "STOPPING CRITERIA", posn="right"))
		.Object@freqConvTest <- as.numeric(.scanParam(.Object, "FREQUENCY FOR CONVERGENCE TESTING", posn="right"))
		.Object@fitQuadSurface <- .logFromChar(.scanParam(.Object, "FIT QUADRATIC SURFACE", posn="right"))
		.Object@simpleExpCoeff <- as.numeric(.scanParam(.Object, "SIMPLEX EXPANSION COEFFICIENT", posn="right"))
		
		.Object@skipLeadInts <- as.numeric(.scanParam(.Object, "NUMBER OF LEADING INTERVALS TO SKIP", posn="right"))
		binBounds <- .scanParam(.Object, "Bin interval boundaries", posn="below", stopon="")
		binBounds <- as.numeric(binBounds)
		
		# Haul Data
		colNames <- c()
		haulName <- ""
		haulData <- NA
		ln <- .firstLineOf(.Object, "Bin interval boundaries")
		# scan in each haul data entry until find 'End'
		while (haulName != "End of haul data") {
			# Skip blank lines
			while (ln < length(.Object@.infileLines) && .trim(.Object@.infileLines[[ln]]) != "") ln <- ln + 1
			if (ln < length(.Object@.infileLines)) {
			ln <- ln + 1
				# Strip off numeric from haul name
				haulName <- .trim(gsub(" ([0-9,-]+$)", "", .Object@.infileLines[[ln]]))
				if (haulName != "End of haul data") {
					colNames <- c(colNames, haulName)
					# scan in next chunk of haul data
					hd <- as.numeric(.scanData(.Object, startln=(ln+1), stopon=""))
					while (length(hd) < length(binBounds)) hd <- c(hd, NA)
					if (!is.matrix(haulData)) haulData <- matrix(nrow=length(hd), ncol=0)
					haulData <- cbind(haulData, matrix(hd, ncol=1, byrow=T))
				}
			}
		}
		dimnames(haulData) <- list(binBounds, colNames)
		.Object@haulData <- as.data.frame(haulData)
		
		return(.Object)
	}
)

# HELPER METHODS
# Return data found either to the 'right' of a 'textflag' label or 'below' it.
# For 'below' the scan end is dependent on how many 'nlines' to scan and what
# character string to 'stopon'
setGeneric(".scanParam", function(.Object, textflag="character", posn="character", nlines="integer", 
														skip="integer", stopon) standardGeneric(".scanParam"))
setMethod(".scanParam", "CMIX",
	function(.Object, textflag, posn="right", nlines=1, skip=0, stopon) {
		param <- NA
		textln <- .firstLineOf(.Object, textflag)
		
		if (textln > 0) {
			if (posn == "right") param <- .trim(sub(textflag, "", .Object@.infileLines[[textln]]))
			if (posn == "below") {
				startln <- stopln <- textln + skip + 1
				nln <- 0
				if (!missing(stopon) && startln <= length(.Object@.infileLines)) {
					# find next stopon line
					while (stopln < length(.Object@.infileLines) && .trim(.Object@.infileLines[[stopln]]) != stopon
							&& !.startswith(.Object@.infileLines[[stopln]], stopon)) stopln <- stopln + 1
				}
				if (nlines > 1 && (startln + nlines - 1) < stopln && (startln + nlines - 1) < length(.Object@.infileLines)) {
					nln <- nlines
				} else if (stopln > startln && stopln < length(.Object@.infileLines)) {
					nln <- stopln - startln + 1
				} else {
					return(param)
				}
				param <- scan(.Object@infilepath, what="numeric", skip=(startln - 1), nlines=nln, quiet=T)
			}
		}
		
		return(param)
	}
)

# Scan in a chunk of data (whitespace separated numerics)  Start and end is determined by the 'startln', 
# how many lines to 'skip', how many 'nlines' to scan and what character string to 'stopon'.
setGeneric(".scanData", function(.Object, startln="integer", nlines="integer", 
														skip="integer", stopon) standardGeneric(".scanData"))
setMethod(".scanData", "CMIX",
	function(.Object, startln, nlines=1, skip=0, stopon) {
		param <- NA
		
		if (!missing(startln) && startln < length(.Object@.infileLines)) {
			stopln <- startln
			nln <- 0
			if (!missing(stopon)) {
				# find next stopon line
				while (stopln < length(.Object@.infileLines) && .trim(.Object@.infileLines[[stopln]]) != stopon
							&& !.startswith(.Object@.infileLines[[stopln]], stopon)) stopln <- stopln + 1
			}
			if (nlines > 1 && (startln + nlines - 1) < stopln && (startln + nlines - 1) < length(.Object@.infileLines)) {
				nln <- nlines
			} else if (stopln > startln && stopln < length(.Object@.infileLines)) {
				nln <- stopln - startln + 1
			} else {
				return(param)
			}
			param <- scan(.Object@infilepath, what="numeric", skip=(startln - 1), nlines=nln, quiet=T)
		
		}

		return(param)
	}
)

# Return the line number of the first line in which 'findtext' appears (else 0)
setGeneric(".firstLineOf", function(.Object, findtext="character") standardGeneric(".firstLineOf"))
setMethod(".firstLineOf", "CMIX",
	function(.Object, findtext) {
		if (!missing(findtext)) {
			titlns <- grep(findtext, .Object@.infileLines)
			if (length(titlns) > 0) return(titlns[[1]])
		}
		
		return(0)
	}
)

setGeneric(".trim", function(x) standardGeneric(".trim"))
setMethod(".trim", "character",
	function(x) {
		return(gsub("(^ +)|( +$)", "", x))
	}
)
	
setGeneric(".startswith", function(x, stwith) standardGeneric(".startswith"))
setMethod(".startswith", "character",
	function(x, stwith) {
		return(length(grep(paste("(^", stwith, ")", sep=""), .trim(x))) > 0)
	}
)

# Return a text string with label left aligned and value padded to start at valcol
# Parameters:
#	label	character	text string
#	value	character	parameter value
#	valcol	integer		column at which to pad value to inclusively
setGeneric(".padTo", function(label, value, valcol="integer") standardGeneric(".padTo"))
setMethod(".padTo", "character",
    function(label="", value="", valcol=41) {
		if (nchar(label) >= valcol + 1) stop("Label '", label, "' is longer than padding space: ", valcol)
		
		return(paste(format(label, justify="left", width=(valcol - 1)), value, sep=""))
	}
)

# Return a text string with each element of a vector formatted numcol to a line and in columns
# with a minimum of minpad spaces between each column element
# Parameters:
#	x		vector	vector of elements
#	numcol 	numeric	number of element columns to a row
#	minpad	numeric	minimum padding between columns
setGeneric(".padBy", function(x, numcol="integer", minpad="integer", width) standardGeneric(".padBy"))
setMethod(".padBy", "vector",
    function(x, numcol=10, minpad=1, width) {
		if (!is.vector(x) || numcol < 1 || minpad < 1) stop("Invalid params passed to .padBy")
		
		output <- ""
		colwidth <- ifelse(missing(width), .maxColWidth(x) + minpad, width + minpad)
		for (ln in 1:ceiling(length(x)/numcol)) {
			if (output != "") output <- paste(output, "\n", sep="")
			for (val in (numcol*(ln-1)+1):(numcol*ln)) {
				output <- paste(output, format(as.character(ifelse(is.na(x[val]),"",x[val])), justify="left", width=colwidth), sep="")
			}
#			output <- paste(output, format(x[(numcol*(ln-1)+1):(numcol*ln)], justify="left", width=colwidth))
		}
		
		return(output)
	}
)

# Return a character representation of the logical x based on 'as'
# "TF" = TRUE/FALSE
# "tf" = true/false
# "YN" = YES/NO
# "yn"	= yes/no
setGeneric(".logAsChar", function(x, as="character") standardGeneric(".logAsChar"))
setMethod(".logAsChar", "logical",
	function(x, as="TF") {
		if (as == "TF") return(ifelse(x, "TRUE", "FALSE"))
		if (as == "tf") return(ifelse(x, "true", "false"))
		if (as == "YN") return(ifelse(x, "YES", "NO"))
		if (as == "yn") return(ifelse(x, "yes", "no"))
	}
)

# Return a logical from the character representation passed
setGeneric(".logFromChar", function(x) standardGeneric(".logFromChar"))
setMethod(".logFromChar", "character",
	function(x) {
		if (x == "TRUE" || x == "true" || x == "YES" || x == "yes") return(TRUE)
		if (x == "FALSE" || x == "false" || x == "NO" || x == "no") return(FALSE)
		return(NA)
	}
)

# Find the maximum character width of any data.frame or vector element
setGeneric(".maxColWidth", function(x) standardGeneric(".maxColWidth"))
setMethod(".maxColWidth", "data.frame",
	function(x) {
		dfmax <- 0
		for (coln in 1:length(x)) {
			x[is.na(x)] <- ""
			colmax <- max(nchar(x[[coln]]), keepNA = T)
			if (colmax > dfmax) dfmax <- colmax
		}
		
		return(dfmax)
	}
)
setMethod(".maxColWidth", "vector",
	function(x) {
		x[is.na(x)] <- ""
		return(max(nchar(x)))
	}
)

# WRAPPER (CONVENIENCE) FUNCTIONS
# Build a new CMIX input file from the function parameters/defaults
buildCMIX <- function(infilepath="CMIXInput.dat", hauldatafilepath=system.file("extdata", "demoHaulData.csv", package="CMIX"), 
						components=matrix(nrow=0,ncol=0), sdBounds=matrix(nrow=0,ncol=0), linearlyRelated=TRUE,
						loLinIntr=1, upLinIntr=50, loLinSlope=0.0, upLinSlope=0.4, stValIntr=15, 
						stepLenIntr=1, stValSlope=0.07, stepLenSlope=0.01,
						minimisation=TRUE, fitQuadSurface=FALSE, plotFittedFn=TRUE, plotResidualFn=TRUE,
						plotToScreen=FALSE, plotToPlotter=FALSE, plotToPrinter=FALSE, plotToFile=TRUE,
						maxFnCalls=10000, minimRepFreq=100, stoppingCrit=0.000001, freqConvTest=5,
						simpleExpCoeff=1, skipLeadInts=0, ...) {
	if (hauldatafilepath == system.file("extdata", "demoHaulData.csv", package="CMIX")) {
		message("Build using existing CMIX DEMO haul data!")
		if (missing(components)) components <- matrix(c(280,310,315,440), ncol=2, byrow=TRUE)
		if (missing(sdBounds)) sdBounds <- matrix(c(5,50,5,50), ncol=2, byrow=TRUE)
		if (missing(skipLeadInts)) skipLeadInts <- 6
	}					
	c <- new ("CMIX", infilepath=infilepath, hauldatafilepath=hauldatafilepath,
						components=components, sdBounds=sdBounds, linearlyRelated=linearlyRelated,
						loLinIntr=loLinIntr, upLinIntr=upLinIntr, loLinSlope=loLinSlope, upLinSlope=upLinSlope, 
						stValIntr=stValIntr, stepLenIntr=stepLenIntr, stValSlope=stValSlope, stepLenSlope=stepLenSlope,
						minimisation=minimisation, fitQuadSurface=fitQuadSurface, plotFittedFn=plotFittedFn, 
						plotResidualFn=plotResidualFn, plotToScreen=plotToScreen, plotToPlotter=plotToPlotter, 
						plotToPrinter=plotToPrinter, plotToFile=plotToFile,
						maxFnCalls=maxFnCalls, minimRepFreq=minimRepFreq, stoppingCrit=stoppingCrit, 
						freqConvTest=freqConvTest, simpleExpCoeff=simpleExpCoeff, skipLeadInts=skipLeadInts, ...)
	c <- buildInput(c)
	
	message("CMIX input file written to: ", infilepath)

	return(invisible(c))
}

# Build a new CMIX input file from the function parameters/defaults and generate component bounds from VB params
buildVBCMIX <- function(infilepath="CMIXInput.dat", hauldatafilepath=system.file("extdata", "demoHaulData.csv", package="CMIX"), 
						sdBounds=matrix(nrow=0,ncol=0), linearlyRelated=TRUE,
						loLinIntr=1, upLinIntr=50, loLinSlope=0.0, upLinSlope=0.4, stValIntr=15, 
						stepLenIntr=1, stValSlope=0.07, stepLenSlope=0.01,
						minimisation=TRUE, fitQuadSurface=FALSE, plotFittedFn=TRUE, plotResidualFn=TRUE,
						plotToScreen=FALSE, plotToPlotter=FALSE, plotToPrinter=FALSE, plotToFile=TRUE,
						maxFnCalls=10000, minimRepFreq=100, stoppingCrit=0.000001, freqConvTest=5,
						simpleExpCoeff=1, skipLeadInts=0, 
						birthday=1, surveyStartDay=0, t0=0, K=1, Linfinity=1, proportion=0.5, firstCohort=1, 
						numCohorts=1, withmeans=FALSE, useCandyDecay=FALSE, decay=0, cutoff=0,
						...) {
	if (hauldatafilepath == system.file("extdata", "demoHaulData.csv", package="CMIX")) {
		message("Build using existing CMIX DEMO haul data!")
		#if (missing(components)) components <- matrix(c(280,310,315,440), ncol=2, byrow=TRUE)
		if (missing(sdBounds)) sdBounds <- matrix(c(5,50,5,50), ncol=2, byrow=TRUE)
		if (missing(skipLeadInts)) skipLeadInts <- 6
		if (missing(birthday)) birthday <- 325
		if (missing(t0)) t0 <- 0.057
		if (missing(K)) K <- 0.379
		if (missing(Linfinity)) Linfinity <- 438
		if (missing(proportion)) proportion <- 0.5
		if (missing(numCohorts)) numCohorts <- 2
		if (missing(firstCohort)) firstCohort <- 3
	}					
	c <- new ("CMIX", infilepath=infilepath, hauldatafilepath=hauldatafilepath,
						sdBounds=sdBounds, linearlyRelated=linearlyRelated,
						loLinIntr=loLinIntr, upLinIntr=upLinIntr, loLinSlope=loLinSlope, upLinSlope=upLinSlope, 
						stValIntr=stValIntr, stepLenIntr=stepLenIntr, stValSlope=stValSlope, stepLenSlope=stepLenSlope,
						minimisation=minimisation, fitQuadSurface=fitQuadSurface, plotFittedFn=plotFittedFn, 
						plotResidualFn=plotResidualFn, plotToScreen=plotToScreen, plotToPlotter=plotToPlotter, 
						plotToPrinter=plotToPrinter, plotToFile=plotToFile,
						maxFnCalls=maxFnCalls, minimRepFreq=minimRepFreq, stoppingCrit=stoppingCrit, 
						freqConvTest=freqConvTest, simpleExpCoeff=simpleExpCoeff, skipLeadInts=skipLeadInts,
						...)
	c <- setVBBounds(c, birthday=birthday, surveyStartDay=surveyStartDay, t0=t0, K=K, Linfinity=Linfinity, 
						proportion=proportion, firstCohort=firstCohort, numCohorts=numCohorts,
						withmeans=withmeans, useCandyDecay=useCandyDecay, decay=decay, cutoff=cutoff)
	c <- buildInput(c)
	
	message("CMIX input file written to: ", infilepath)

	return(invisible(c))
}

# Take an existing CMIX input file and pull data into a CMIX object
parseCMIX <- function(infilepath=system.file("extdata", "demoCMIXInput.dat", package="CMIX")) {
	if (infilepath == system.file("extdata", "demoCMIXInput.dat", package="CMIX")) {
		message("Parsing existing CMIX DEMO input data!")
	}
	if (!file.exists(infilepath)) stop("Cannot find input file at: ", infilepath)
	
	c <- new("CMIX", infilepath=infilepath)
	c <- parseInput(c)
	
	return(invisible(c))
}

# Make a system call to CMIX executable with CMIX input data file
runCMIX <- function(infilepath=system.file("extdata", "demoCMIXInput.dat", package="CMIX"), outfilepath) {
	if (infilepath == system.file("extdata", "demoCMIXInput.dat", package="CMIX")) {
		message("Running CMIX with DEMO input data!")
	}
	if (!file.exists(infilepath)) stop("Cannot find input file at: ", infilepath)
	
	c <- new("CMIX", infilepath=infilepath)
	c <- runInput(c, outfilepath=outfilepath)
	
	message("CMIX output file written to: ", c@outfilepath)
	
	return(invisible(c))
}

# Plot results from the CMIX output data file.
plotCMIX <- function(outfilepath=system.file("extdata", "demoCMIXOutput.dat", package="CMIX"), bars=c("ci", "se"), onedev=TRUE) {
	
	# Process output file
	results <- resultsCMIX(outfilepath)
	
	if (outfilepath == system.file("extdata", "demoCMIXOutput.dat", package="CMIX")) {
		message("Plotting results from DEMO CMIX output!")
	}
	
	# calc layout for plots on device
	if (onedev) {
		c1 <- !is.null(results[["meandensities"]])
		c2 <- !is.null(results[["densities"]])
		r1 <- ("ci" %in% bars) 
		r2 <- ("se" %in% bars)
		plotposns <- matrix(c(r1&c1, r2&c1, r1&c2, r2&c2), 2, 2)
		plotcnt <- length(plotposns[plotposns==T])
		plotposns[plotposns==T]<-1:plotcnt
		layout(plotposns)
	}
	
	# Distribution
	if (!is.null(results[["densities"]])) {
		if ("ci" %in% bars) {
			.makeBarPlotWithCI(t(subset(results$densities, select=1)), 
							bar.lo=t(subset(results$densities, select=3)), 
							bar.up=t(subset(results$densities, select=4)), 
							main="Density Distribution (C.I.)", xlab="Total Length (mm)", ylab="Density", col="dark red", newdev=!onedev)
		} 
		if ("se" %in% bars) {
			.makeBarPlotWithCI(t(subset(results$densities, select=1)), 
							bar.up=(t(subset(results$densities, select=1)) + t(subset(results$densities, select=2))), 
							main="Density Distribution (S.E.)", xlab="Total Length (mm)", ylab="Density", col="dark red", newdev=!onedev)
		}
	}
	
	# Length Density
	if (!is.null(results[["meandensities"]])) {
		# Observed
		if ("ci" %in% bars) {
			ci.lo <- t(subset(results$meandensities, select=3))
			ci.up <- t(subset(results$meandensities, select=4))
			.makePlotWithCI(x=as.numeric(rownames(results$meandensities)), y=t(subset(results$meandensities, select=1)), 
						bar.lo=ci.lo, bar.up=ci.up,
						main="Length Density (C.I.)", xlab="Total Length (mm)", ylab="Density", newdev=!onedev)
			# Expected
			lines(x=rownames(results$meandensities), y=t(subset(results$meandensities, select=2)), col="blue")
			ci.up[array(ci.up>1e+25)] <- 0
			legend(min(as.numeric(rownames(results$meandensities))), max(ci.up),
					legend=c("Observed", "Expected"), lty=c(NA, 1), pch=c(19, NA), col=c("dark red", "blue"), cex=c(0.75))
		} 
		if ("se" %in% bars) {
			se.lo <- NULL
			se.up <- NULL
			if (!is.null(results[["densities"]])) {
				se.lo <- (t(subset(results$meandensities, select=1)) - t(subset(results$densities, select=2)))
				se.up <- (t(subset(results$meandensities, select=1)) + t(subset(results$densities, select=2)))
			}
			.makePlotWithCI(x=as.numeric(rownames(results$meandensities)), y=t(subset(results$meandensities, select=1)), 
						bar.lo=se.lo, bar.up=se.up,
						main="Length Density (S.E.)", xlab="Total Length (mm)", ylab="Density", newdev=!onedev)
			# Expected
			lines(x=rownames(results$meandensities), y=t(subset(results$meandensities, select=2)), col="blue")
			legend(min(as.numeric(rownames(results$meandensities))), 
					max(se.up, t(subset(results$meandensities, select=1)), t(subset(results$meandensities, select=2))),
					legend=c("Observed", "Expected"), lty=c(NA, 1), pch=c(19, NA), col=c("dark red", "blue"), cex=c(0.75))
		}
	}
}

# Parse a CMIX output file and return the results as a list.  Which results returned are determined by 'sets' parameter.
resultsCMIX <- function(outfilepath=system.file("extdata", "demoCMIXOutput.dat", package="CMIX"), 
						sets=c("densities", "meandensities", "sumdensities", "components", "linearsd")) {
	
	if (outfilepath == system.file("extdata", "demoCMIXOutput.dat", package="CMIX")) {
		message("Returning results from DEMO CMIX output!")
	}
	if (!file.exists(outfilepath)) stop("Cannot find output file at: ", outfilepath)
	
	# Check that it was able to converge "*** ERROR: !!! Unable to converge on minimum !!! ***"
	if (length(grep("Unable to converge on minimum", readLines(outfilepath)))) {
		stop("CMIX failed to converge on a minimum!")
	}
	
	results <- list()
	outlines <- readLines(outfilepath)
	if ("densities" %in% sets) {
		titlns <- grep("Table of densities for each length class", outlines)
		densities <- NULL
		if (length(titlns) > 0) {
			# Find first line
			stln <- ln <- titlns[[1]] + 4
			# Find the last line
			while (ln < length(outlines) && outlines[[ln]] != "") ln <- ln + 1
			densities <- scan(outfilepath, skip=(stln-1), nlines=(ln-stln), quiet=T) 
			densities <- matrix(densities, ncol=5, byrow=T)
			# Add dim names
			dimnms <- list(densities[1:nrow(densities)], c("Length", "Density", "S.E.", "Lower C.I.", "Upper C.I."))
			dimnames(densities) <- dimnms
			densities <- subset(densities, select=c(2,3,4,5))
			ifelse(length(sets) > 1, results[["densities"]] <- densities, results <- densities)
			#densities <- matrix(densities, nrow=5)
			#dimnms <- list(c("Length", "Density", "S.E.", "Lower C.I.", "Upper C.I."), densities[array(c(seq(1,length(densities),by=5)))])
			#dimnames(densities) <- dimnms
			#densities <- t(subset(t(densities), select=c(2,3,4,5)))
		}
	}
	# Length Density
	if ("meandensities" %in% sets) {
		meandensities <- NULL
		titlns <- grep("Table of observed and expected mean densities", outlines)
		if (length(titlns) > 0) {
			# Find first line
			stln <- ln <- titlns[[1]] + 4
			# Find the last line
			while (ln < length(outlines) && outlines[[ln]] != "") ln <- ln + 1
			meandensities <- scan(outfilepath, skip=(stln-1), nlines=(ln-stln), quiet=T) 
			meandensities <- matrix(meandensities, ncol=5, byrow=T)
			# Add dim names
			dimnms <- list(meandensities[1:nrow(meandensities)], c("Interval", "Observed", "Expected", "Lower C.I.", "Upper C.I."))
			dimnames(meandensities) <- dimnms
			meandensities <- subset(meandensities, select=c(2,3,4,5))
			ifelse(length(sets) > 1, results[["meandensities"]] <- meandensities, results <- meandensities)
		}
	}
	
	if ("sumdensities" %in% sets) {
		sumdensities <- list()
		titlns <- grep("Sum of the observed densities", outlines)
		if (length(titlns) > 0) sumdensities[["sumobserved"]] <- as.double(sub("Sum of the observed densities =", "", outlines[[titlns[[1]]]]))
		
		titlns <- grep("Sum of the expected densities", outlines)
		if (length(titlns) > 0) sumdensities[["sumexpected"]] <- as.double(sub("Sum of the expected densities =", "", outlines[[titlns[[1]]]]))
		ifelse(length(sets) > 1, results[["sumdensities"]] <- sumdensities, results <- sumdensities)
	}
	
	# Component results
	if ("components" %in% sets) {
		components <- list()
		titlns <- grep("Means of mixture components", outlines)
		if (length(titlns) > 0) components[["mean"]] <- scan(outfilepath, skip=titlns[[1]], nlines=1, quiet=T) 
		titlns <- grep("Standard deviations of mixture components", outlines)
		if (length(titlns) > 0) components[["sd"]] <- scan(outfilepath, skip=titlns[[1]], nlines=1, quiet=T) 
		titlns <- grep("Total density of each mixture component", outlines)
		if (length(titlns) > 0) components[["totaldensity"]] <- scan(outfilepath, skip=titlns[[1]], nlines=1, quiet=T) 
		titlns <- grep("SD of each mixture component density", outlines)
		if (length(titlns) > 0) components[["sddensity"]] <- scan(outfilepath, skip=titlns[[1]], nlines=1, quiet=T) 
		ifelse(length(sets) > 1, results[["components"]] <- components, results <- components)
	}
	
	if ("linearsd" %in% sets) {
		linearsd <- list()
		titlns <- grep("Parameters of linear standard deviations", outlines)
		if (length(titlns) > 0) linearsd[["intercept"]] <- as.double(sub("Intercept =", "", outlines[[titlns[[1]] + 1]]))
		if (length(titlns) > 0) linearsd[["slope"]] <- as.double(sub("Slope     =", "", outlines[[titlns[[1]] + 2]]))
		ifelse(length(sets) > 1, results[["linearsd"]] <- linearsd, results <- linearsd)
	}
	
	return(results)
}
 
# Some plotting wrapper functions.
.makePlotWithCI <- function(x, y, bar.lo, bar.up, leg, newdev=TRUE, ...) {
	if (newdev) dev.new()
	# remove infinite upper and lowers
	if (!missing(bar.up) && !is.null(bar.up)) bar.up[array(bar.up>1e+25)] <- 0
	if (!missing(bar.lo) && !is.null(bar.lo)) bar.lo[array(bar.lo<1e-25)] <- 0
	tlen <- 1.5
	ymax <- ifelse(!missing(bar.up) && !is.null(bar.up), max(bar.up), max(y))
	op <- par(ps=10, pch=19, col="dark red")	#, cex=0.75
	plot(x=x, y=y, ylim=c(0,ymax), ...)
	#plot(x=x, y=y, ...)
	
	for (i in 1:length(x)) {
		if (!missing(bar.up) && !is.null(bar.up)) {		# Upper
			stY <- ifelse((y[i]+tlen >= 0) && (y[i]+tlen < bar.up[i]), y[i]+tlen, NA)
			enY <- ifelse((bar.up[i] >= 0) && (bar.up[i] > y[i]+tlen), bar.up[i], NA)
			if (!is.na(stY) && !is.na(enY)) {
				segments(x0=x[i], y0=stY, y1=enY)
				segments(x0=x[i]-tlen, y0=enY, x1=x[i]+tlen)
			}
		}
		if (!missing(bar.lo) && !is.null(bar.lo)) {		# Lower
			stY <- ifelse((y[i]-tlen >= 0) && (y[i]-tlen > bar.lo[i]), y[i]-tlen, NA)
			enY <- ifelse((bar.lo[i] >= 0) && (bar.lo[i] < y[i]-tlen), bar.lo[i], NA)
			if (!is.na(stY) && !is.na(enY)) {
				segments(x0=x[i], y0=stY, y1=enY)
				segments(x0=x[i]-tlen, y0=enY, x1=x[i]+tlen)
			}
		}
	}
	if (!missing(leg)) legend(min(x), legend=leg, pch=par("pch"), col=par("col"))
	
	par(op)
}

.makeBarPlotWithCI <- function(values, bar.lo, bar.up, newdev=TRUE, ...) {
	if (newdev) dev.new()
	# remove infinite upper and lowers
	if (!missing(bar.up) && !is.null(bar.up)) bar.up[array(bar.up>1e+25)] <- 0
	if (!missing(bar.lo) && !is.null(bar.lo)) bar.lo[array(bar.lo<1e-25)] <- 0
	ymax <- ifelse(!missing(bar.up) && !is.null(bar.up), max(bar.up), max(values))
	op <- par(ps=10)
	mpts <- barplot(values, ylim=c(0,ymax), ...)
	#mpts <- barplot(values, ...)
	tlen <- (mpts[2] - mpts[1]) / 8
	
	if (!missing(bar.up) && !is.null(bar.up)) {
		segments(x0=mpts, y0=values, y1=bar.up)
		segments(x0=mpts-tlen, y0=bar.up, x1=mpts+tlen)
	}
	if (!missing(bar.lo) && !is.null(bar.lo)) {
		segments(x0=mpts, y0=values, y1=bar.lo)
		segments(x0=mpts-tlen, y0=bar.lo, x1=mpts+tlen)
	}
	par(op)
}

## Build CMIX input CSV files for buildCMIX
CMIXinput <- function(lbin,data, volume, proportion,area=1, trawl, filename=NULL){
  vols <- data[,as.character(substitute(volume))]
  props <- data[,as.character(substitute(proportion))]
  trawl <- data[,as.character(substitute(trawl))]
  sdat<-data.frame(trawl=trawl, props=props, vols=vols)
  input<-lbin
  names(input)[1]<-"bins"
  input <- sapply(input, as.numeric)
  input <- as.data.frame(input)
  #run the loop on each column of the length bins
  for(h in colnames(lbin)[-1]) {
    vol  <- sdat$vols[sdat$trawl==h]
    prop <- sdat$props[sdat$trawl==h]
    input[,h] <- ((input[,h]/vol)*prop)*area
  }
  
  binwidth<-input$bins[nrow(input)]-input$bins[nrow(input)-1]
  
  input[nrow(input)+1,] <- ""
  input$bins[nrow(input)]<-as.numeric(max(input$bins))+as.numeric(binwidth)
  if(!is.null(filename)){write.csv(input, file = filename,row.names =FALSE)}
}

#######################################################################################################
## Testing
# buildCMIX(infilepath="CMIXInput.dat", hauldatafilepath="HaulData.csv", 
		   # components=matrix(c(280,310,315,440), ncol=2, byrow=TRUE),
		   # sdBounds=matrix(c(5,50,5,50), ncol=2, byrow=TRUE),
		   # skipLeadInts=6)
		   
# if (runCMIX("CMIXInput.dat", "CMIXOutput.dat")) {
	# plotCMIX("CMIXOutput.dat")
# }

# resultsCMIX("CMIXOutput.dat")

#c <- new("CMIX", infilepath="CMIXInput.dat")
#c <- parseInput(c)

# c <- new("CMIX", hauldatafilepath="HaulData.csv")
# c <- setVBBounds(c, surveyStartDay=0, birthday=325, t0=0.057, K=0.379, Linfinity=438, proportion=0.5, numCohorts=2, firstCohort=3, useCandyDecay=FALSE) 

											   
											   
